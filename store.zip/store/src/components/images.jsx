import visa from '../assets/visa.svg';
import stripe from '../assets/stripe.svg';
import paypal from '../assets/paypal.svg';
import payment from '../assets/payment.svg';
import email from '../assets/email.svg';
import laptop from '../assets/laptop.png';
import laptop2 from '../assets/laptop2.png';
import laptop3 from '../assets/laptop3.png';
import mobile from '../assets/mobile.png';
import smartphone from '../assets/smartphone.png';
import headphone from '../assets/headphone.png';
import cam from '../assets/cam.png';
import camera from '../assets/camera.png';
import tablet from '../assets/tablet.png';
import hp from '../assets/hp.png';
import headphone2 from '../assets/headphone2.png';

const images = {
  visa,       
  stripe,     
  paypal,      
  payment,
  email,      
  laptop,    
  laptop2,     
  laptop3,
  mobile,      
  smartphone,
  headphone,   
  headphone2,
  cam,         
  camera,
  tablet,      
  hp
};

export default images;
