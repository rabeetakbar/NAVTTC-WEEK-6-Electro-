import React from 'react';
import Homesec2 from './Homesec2';
const HotDeals = () => {
  return( <div>
    <Homesec2/>
  </div>

)};

export default HotDeals;
